/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const log: (a: number, b: number) => void;
export const log_error: (a: number, b: number) => void;
export const detect_platform: (a: number, b: number) => [number, number];
export const extract_media_from_html: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
export const process_media_batch: (a: number, b: number) => [number, number];
export const start: () => void;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
