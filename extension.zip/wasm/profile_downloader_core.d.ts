/* tslint:disable */
/* eslint-disable */

/**
 * Parse a profile URL and return detected platform type.
 */
export function detect_platform(url: string): string | undefined;

/**
 * Extract media from a profile page HTML (called from content script).
 */
export function extract_media_from_html(platform: string, html: string, page_url: string): string;

/**
 * Log a message to the browser console.
 */
export function log(msg: string): void;

/**
 * Log an error to the browser console.
 */
export function log_error(msg: string): void;

/**
 * Process a batch of media items (validate, deduplicate, sort).
 */
export function process_media_batch(json_input: string): string;

/**
 * Initialize the WASM module (logging, config).
 */
export function start(): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly log: (a: number, b: number) => void;
    readonly log_error: (a: number, b: number) => void;
    readonly detect_platform: (a: number, b: number) => [number, number];
    readonly extract_media_from_html: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly process_media_batch: (a: number, b: number) => [number, number];
    readonly start: () => void;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
